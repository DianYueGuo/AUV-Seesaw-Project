# orca_ros_bridge
ros1-to-ros2 bridge container

## Usage
1. build container
```
./script/build.sh
```
2. execute bridge (ensure ros1 core is running)
```
./script/run
```
